import asyncio
import logging

import discord
from discord.ext import commands

import config

logging.basicConfig(level=logging.INFO)

intents = discord.Intents.default()
intents.members = True  # nécessaire pour lire channel.members et attribuer des rôles
intents.message_content = True  # nécessaire pour détecter les pièces jointes (carte identité, permis)

bot = commands.Bot(command_prefix="!", intents=intents)


@bot.event
async def on_ready():
    print(f"Connecté en tant que {bot.user} (ID: {bot.user.id})")
    # ORDRE IMPORTANT : on copie/synchronise d'abord vers le serveur (pendant
    # que les commandes sont encore dans l'arbre global en memoire), PUIS
    # seulement apres on nettoie le global cote Discord (source des doublons).
    GUILD_OIL_ROXWOOD = discord.Object(id=1245400912835510283)
    try:
        bot.tree.copy_global_to(guild=GUILD_OIL_ROXWOOD)
        synced_guild = await bot.tree.sync(guild=GUILD_OIL_ROXWOOD)
        print(f"{len(synced_guild)} commande(s) synchronisee(s) sur Oil RoxWood (instantane).")
    except Exception as e:
        print(f"Erreur sync ciblee serveur : {e!r}")

    # Nettoyage des anciennes commandes GLOBALES, APRES la copie ci-dessus.
    # Prend jusqu'a 1h a disparaitre cote Discord, mais fait une seule fois.
    bot.tree.clear_commands(guild=None)
    await bot.tree.sync()


async def main():
    async with bot:
        await bot.load_extension("cogs.candidature")
        await bot.load_extension("cogs.rh_grades")
        await bot.load_extension("cogs.rh_evenements")
        await bot.load_extension("cogs.recrutement_suivi")
        await bot.load_extension("cogs.cloture_commande")
        await bot.load_extension("cogs.moderation")
        await bot.load_extension("cogs.gazette")
        await bot.load_extension("cogs.salons_vocaux_temp")
        await bot.load_extension("cogs.tirage")
        await bot.load_extension("cogs.recap_mensuel")
        await bot.load_extension("cogs.contrat")
        await bot.load_extension("cogs.logs_recherche")
        await bot.load_extension("cogs.rappel")
        await bot.load_extension("cogs.sauvegarde")
        await bot.load_extension("cogs.moderation_utils")
        await bot.load_extension("cogs.stats")
        await bot.load_extension("cogs.bienvenue")
        await bot.load_extension("cogs.antispam")
        await bot.load_extension("cogs.depart_discord")
        await bot.load_extension("cogs.webhooks_activite")
        await bot.load_extension("cogs.commercial")
        await bot.load_extension("cogs.absences")
        await bot.load_extension("cogs.ticket_tool_replace")
        await bot.load_extension("cogs.vehicules")
        await bot.load_extension("cogs.classement")
        await bot.load_extension("cogs.recap_hebdo")
        await bot.load_extension("cogs.badges_top_vendeur")
        await bot.load_extension("cogs.aide")
        await bot.load_extension("cogs.verification_acces")
        await bot.load_extension("cogs.ticket_permissions_auto")
        await bot.load_extension("cogs.site_bridge")
        await bot.load_extension("cogs.webhooks_logs_supplementaires")
        await bot.load_extension("cogs.close_ticket")
        await bot.load_extension("cogs.facture")
        await bot.load_extension("cogs.blacklist")
        await bot.load_extension("cogs.timeout")
        await bot.start(config.BOT_TOKEN)


if __name__ == "__main__":
    asyncio.run(main())
