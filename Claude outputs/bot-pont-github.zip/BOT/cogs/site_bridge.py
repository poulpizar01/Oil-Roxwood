"""
Pont entre le site Oil Roxwood et Discord.

⚠️ Ce fichier remplace `cogs/supabase_bridge.py`. Le nom a changé parce que la
plomberie a changé : le site ne passe plus par Supabase depuis septembre 2026,
il vit dans son dépôt GitHub (`data/etat.json`). Le bot écrivait donc dans une
base que plus personne ne lisait, et le site déposait des ordres que le bot
n'allait plus chercher.

Ce qui n'a PAS changé : tout ce qui fabrique l'image d'éligibilité, les
couleurs, les polices, la recherche du grade. C'est repris tel quel, ligne
pour ligne. Seule la façon d'aller chercher les ordres et d'y répondre a été
réécrite.

Comment ça marche maintenant
----------------------------
· lecture  : raw.githubusercontent.com — public, sans jeton, sans quota
· écriture : API GitHub Contents, avec un jeton personnel du bot
· conflits : le SHA du fichier fait office de jeton de version. Si un admin
             enregistre entre notre lecture et notre écriture, GitHub refuse,
             on relit et on rejoue. C'est pour ça que la modification est
             passée sous forme de fonction : elle doit pouvoir être rejouée.
· ordres   : GitHub n'a pas de temps réel. On interroge le fichier toutes les
             20 secondes. Le site attend la réponse du bot pendant 25 s avant
             de dire « le bot semble hors ligne » : on reste donc dans les temps.

À mettre dans cogs/.env
-----------------------
  ORX_GH_TOKEN=github_pat_…     jeton *fine-grained*, dépôt Oil-Roxwood seul,
                                permission « Contents : Read and write »

Les lignes SUPABASE_URL, SUPABASE_KEY, ORX_BOT_EMAIL et ORX_BOT_PASSWORD ne
servent plus à rien et peuvent être supprimées.
"""

import asyncio
import io
import logging
from pathlib import Path

import discord
from discord.ext import commands
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import base64
import json
import os
import time
import urllib.error
import urllib.request

import config
import database as db

logger = logging.getLogger("oilroxwood.site_bridge")

# --- A confirmer avec le dev du site ---
TYPE_ORDRE_ELIGIBILITE = "eligibilite_image"

# --- Le depot GitHub qui sert de base au site ---
GH_OWNER = os.getenv("ORX_GH_OWNER", "poulpizar01")
GH_REPO = os.getenv("ORX_GH_REPO", "Oil-Roxwood")
GH_BRANCHE = os.getenv("ORX_GH_BRANCHE", "main")
GH_FICHIER = os.getenv("ORX_GH_FICHIER", "data/etat.json")
GH_JETON = (os.getenv("ORX_GH_TOKEN", "") or getattr(config, "ORX_GH_TOKEN", "") or "").strip()

GH_RAW = f"https://raw.githubusercontent.com/{GH_OWNER}/{GH_REPO}/{GH_BRANCHE}/{GH_FICHIER}"
GH_API = f"https://api.github.com/repos/{GH_OWNER}/{GH_REPO}/contents/{GH_FICHIER}"
GH_UA = f"OilRoxwoodBot (https://github.com/{GH_OWNER}/{GH_REPO}, 2.0)"

INTERVALLE_SONDAGE = 20      # secondes entre deux relectures du depot
ESSAIS_ECRITURE = 4          # tentatives en cas de conflit avec un admin

# --- Salon Discord ou poster l'image d'eligibilite ---
SALON_ELIGIBILITE_ID = 1472962998162428148

# --- Assets / polices (reprend le meme style que classement.py) ---
_ASSETS_DIR = Path(__file__).parent.parent / "assets"
_BG_IMG_PATH = _ASSETS_DIR / "classement_bg.jpg"
_FONT_DIR = Path("/usr/share/fonts/truetype/dejavu")
SCALE = 1.7

TEXTE = (255, 250, 245)
TEXTE_MUTED = (225, 213, 200)
ACCENT = (250, 150, 65)

GRADE_COULEURS = {
    "Direction": (170, 170, 175),
    "Expert": (230, 70, 70),
    "Confirmé": (240, 150, 60),
    "Raffineur": (70, 140, 230),
    "Intérimaire": (90, 200, 90),
}
COULEUR_GRADE_INCONNU = (110, 105, 98)


def _f(taille, bold=False, cond=False):
    nom = ("DejaVuSansCondensed-Bold.ttf" if bold else "DejaVuSansCondensed.ttf") if cond \
        else ("DejaVuSans-Bold.ttf" if bold else "DejaVuSans.ttf")
    try:
        return ImageFont.truetype(str(_FONT_DIR / nom), int(taille * SCALE))
    except OSError:
        nom_repli = "DejaVuSans-Bold.ttf" if bold else "DejaVuSans.ttf"
        try:
            return ImageFont.truetype(str(_FONT_DIR / nom_repli), int(taille * SCALE))
        except OSError:
            return ImageFont.load_default()


def _s(valeur):
    return int(valeur * SCALE)


class SiteBridgeCog(commands.Cog):
    """Va chercher les ordres du site dans le depot et y repond."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.actif = bool(GH_JETON)
        self._boucle = None

    # ------------------------------------------------------------------
    #  Acces au depot
    # ------------------------------------------------------------------
    @staticmethod
    def _entetes():
        h = {"Accept": "application/vnd.github+json",
             "X-GitHub-Api-Version": "2022-11-28",
             "User-Agent": GH_UA}
        if GH_JETON:
            h["Authorization"] = f"Bearer {GH_JETON}"
        return h

    @classmethod
    def _lire_public(cls):
        """Lecture rapide et sans quota, pour tout ce qui ne modifie rien."""
        req = urllib.request.Request(f"{GH_RAW}?t={int(time.time())}",
                                     headers={"User-Agent": GH_UA})
        with urllib.request.urlopen(req, timeout=30) as r:
            return json.loads(r.read().decode())

    @classmethod
    def _lire_avec_sha(cls):
        req = urllib.request.Request(f"{GH_API}?ref={GH_BRANCHE}&t={int(time.time())}",
                                     headers=cls._entetes())
        with urllib.request.urlopen(req, timeout=30) as r:
            j = json.loads(r.read().decode())
        return json.loads(base64.b64decode(j["content"]).decode("utf-8")), j["sha"]

    @classmethod
    def _ecrire(cls, donnees, sha, message):
        corps = {
            "message": message,
            "content": base64.b64encode(
                json.dumps(donnees, ensure_ascii=False, indent=1).encode()).decode(),
            "branch": GH_BRANCHE,
            "sha": sha,
        }
        req = urllib.request.Request(GH_API, method="PUT",
                                     data=json.dumps(corps).encode(),
                                     headers=cls._entetes())
        urllib.request.urlopen(req, timeout=60).read()

    @classmethod
    def _maj_section(cls, section, mutate, message):
        """Modifie une section de l'etat partage, en rejouant en cas de conflit.

        `mutate` doit etre rejouable : si un admin a enregistre entre notre
        lecture et notre ecriture, GitHub refuse et on recommence sur l'etat
        frais. Les marqueurs _maj / _majSec sont ceux que le dashboard connait,
        il integre la modification a sa prochaine relecture sans ecraser le reste.
        """
        derniere = None
        for tentative in range(ESSAIS_ECRITURE):
            d, sha = cls._lire_avec_sha()
            mutate(d)
            maintenant = int(time.time() * 1000)
            d["_maj"] = maintenant
            d.setdefault("_majSec", {})[section] = maintenant
            d["_cid"] = "bot"
            try:
                cls._ecrire(d, sha, message)
                return
            except urllib.error.HTTPError as e:
                if e.code in (409, 422):          # quelqu'un a ecrit entre-temps
                    derniere = e
                    time.sleep(0.6 * (tentative + 1))
                    continue
                raise
        raise RuntimeError(f"ecriture impossible apres {ESSAIS_ECRITURE} tentatives : {derniere}")

    @staticmethod
    def _ordres(etat):
        return ((etat.get("_tables") or {}).get("oilroxwood_bot_ordres")) or []

    async def _dans_un_fil(self, fn, *a):
        """urllib est bloquant : on le sort de la boucle asyncio du bot, sinon
        le bot se fige pendant chaque appel reseau."""
        return await asyncio.to_thread(fn, *a)

    # ------------------------------------------------------------------
    #  Journal d'activite -- volontairement desactive
    # ------------------------------------------------------------------
    async def envoyer_log(self, type_: str, employe: str = None, quantite: float = None,
                           montant: float = None, details: str = None, meta: dict = None):
        """Conservee pour que les autres cogs (webhooks_activite...) continuent
        de l'appeler sans planter, mais elle n'envoie plus rien.

        Pourquoi : le site ne lit plus les logs depuis une base. Ils sont relus
        directement dans le salon Discord par un robot GitHub, qui ecrit
        data/discord-logs.json. Les recopier dans data/etat.json ferait enfler
        le fichier que TOUS les navigateurs relisent toutes les 45 secondes --
        l'ancienne table en comptait plus de 340 000 lignes.
        """
        return

    # ------------------------------------------------------------------
    #  Cycle de vie
    # ------------------------------------------------------------------
    async def cog_load(self):
        if not self.actif:
            logger.warning("ORX_GH_TOKEN manquant dans cogs/.env — pont site desactive.")
            return
        logger.info("Pont site actif — depot %s/%s (%s)", GH_OWNER, GH_REPO, GH_FICHIER)
        self._boucle = self.bot.loop.create_task(self._boucle_ordres())

    async def cog_unload(self):
        if self._boucle:
            self._boucle.cancel()

    async def _boucle_ordres(self):
        """Le depot n'a pas de temps reel : on le relit regulierement.
        Le premier passage rattrape aussi les ordres deposes pendant que le bot
        etait eteint -- c'est le meme code, il n'y a plus de cas particulier."""
        await self.bot.wait_until_ready()
        while not self.bot.is_closed():
            try:
                etat = await self._dans_un_fil(self._lire_public)
                for ordre in self._ordres(etat):
                    if (ordre.get("statut") or "en_attente") == "en_attente":
                        await self._traiter_ordre(ordre)
            except asyncio.CancelledError:
                raise
            except Exception as e:
                logger.warning("Lecture des ordres impossible : %r", e)
            await asyncio.sleep(INTERVALLE_SONDAGE)

    async def _repondre(self, ordre_id, statut, rapport):
        def _mut(d):
            for o in ((d.setdefault("_tables", {}).setdefault("oilroxwood_bot_ordres", []))):
                if o.get("id") == ordre_id:
                    o["statut"] = statut
                    o["rapport"] = rapport
        await self._dans_un_fil(self._maj_section, "_tables", _mut,
                                f"\U0001F916 Bot — ordre {ordre_id} : {statut}")

    async def _traiter_ordre(self, ordre: dict):
        ordre_id = ordre.get("id")
        type_ordre = ordre.get("type")
        payload = ordre.get("payload") or {}

        try:
            if type_ordre == TYPE_ORDRE_ELIGIBILITE:
                await self._poster_image_eligibilite(payload)
                rapport = "Image d'eligibilite postee sur Discord."
            else:
                logger.info("Ordre %s de type inconnu ignore : %r", ordre_id, type_ordre)
                return
            await self._repondre(ordre_id, "fait", rapport)
            logger.info("Ordre %s traite.", ordre_id)
        except Exception as e:
            logger.error("Erreur en traitant l'ordre %s : %r", ordre_id, e)
            try:
                await self._repondre(ordre_id, "erreur", str(e)[:500])
            except Exception:
                pass

    async def _grade_pour_nom(self, guild: discord.Guild, nom: str) -> str | None:
        """Retrouve le grade d'une personne a partir de son nom RP, via la
        table personnages (nom -> user_id -> membre Discord -> roles)."""
        user_id = db.get_user_id_par_personnage(nom)
        if user_id is None:
            return None
        membre = guild.get_member(user_id)
        if membre is None:
            # Pas en cache -- on tente une requete directe a l'API Discord
            # avant d'abandonner (evite la couleur "grade inconnu" pour des
            # membres juste absents du cache local du bot).
            try:
                membre = await guild.fetch_member(user_id)
            except discord.HTTPException:
                return None
        try:
            from cogs.rh_grades import grade_name_for
            return grade_name_for(membre)
        except ImportError:
            return None

    async def _poster_image_eligibilite(self, payload: dict):
        noms = payload.get("noms") or []
        if not noms:
            raise ValueError("payload.noms vide ou absent")

        await self.bot.wait_until_ready()
        # Le bot est present sur plusieurs serveurs Discord -- on cherche le
        # salon sur TOUS les serveurs (pas juste le premier de la liste, qui
        # n'est pas forcement "Oil Roxwood") pour trouver le bon.
        guild = None
        salon = None
        for g in self.bot.guilds:
            c = g.get_channel(SALON_ELIGIBILITE_ID)
            if c is not None:
                guild = g
                salon = c
                break

        if guild is None or salon is None:
            raise RuntimeError(f"Salon {SALON_ELIGIBILITE_ID} introuvable sur aucun des serveurs du bot")

        lignes = []
        for nom in noms:
            grade = await self._grade_pour_nom(guild, nom)
            lignes.append((nom, grade))

        # Tri : par grade (Direction -> ... -> Intérimaire -> inconnu), puis alphabetique
        ordre_grades = ["Direction", "Expert", "Confirmé", "Raffineur", "Intérimaire"]

        def _cle_tri(item):
            _, grade = item
            idx = ordre_grades.index(grade) if grade in ordre_grades else len(ordre_grades)
            return (idx, item[0].lower())

        lignes.sort(key=_cle_tri)

        buffer = self._generer_image_eligibilite(lignes)
        fichier = discord.File(buffer, filename="eligibilite.png")
        await salon.send(file=fichier)

    def _generer_image_eligibilite(self, lignes: list) -> io.BytesIO:
        n = len(lignes)
        largeur = _s(1280)
        pad_x = _s(56)
        header_h = _s(118)
        nb_col = 4 if n > 24 else (3 if n > 12 else 2)
        lignes_par_col = -(-n // nb_col) if n else 0
        col_w = (largeur - pad_x * 2 - (nb_col - 1) * _s(20)) // nb_col if nb_col else 0
        row_h = _s(38)
        liste_top = pad_x + header_h + _s(20)
        liste_h = lignes_par_col * row_h
        hauteur = liste_top + liste_h + _s(36)

        try:
            bg = Image.open(_BG_IMG_PATH).convert("RGB")
            ratio = max(largeur / bg.width, hauteur / bg.height)
            bg = bg.resize((int(bg.width * ratio), int(bg.height * ratio)))
            left = (bg.width - largeur) // 2
            top = (bg.height - hauteur) // 2
            bg = bg.crop((left, top, left + largeur, top + hauteur)).convert("RGBA")
        except (FileNotFoundError, OSError):
            bg = Image.new("RGBA", (largeur, hauteur), (20, 17, 13, 255))

        grad = Image.new("L", (1, hauteur), 0)
        for y in range(hauteur):
            if y < header_h + pad_x:
                a = 205
            elif y < liste_top - _s(10):
                a = 60
            else:
                a = 190
            grad.putpixel((0, y), a)
        grad = grad.resize((largeur, hauteur))
        voile = Image.new("RGBA", (largeur, hauteur), (8, 6, 5, 255))
        voile.putalpha(grad)
        img = Image.alpha_composite(bg, voile).convert("RGB")
        draw = ImageDraw.Draw(img, "RGBA")

        gx, gy = pad_x, pad_x + _s(4)
        draw.polygon(
            [(gx + _s(12), gy), (gx + _s(24), gy + _s(22)), (gx + _s(24), gy + _s(26)),
             (gx, gy + _s(26)), (gx, gy + _s(22))],
            fill=ACCENT,
        )
        draw.ellipse([gx, gy + _s(13), gx + _s(24), gy + _s(33)], fill=ACCENT)
        draw.text((gx + _s(36), pad_x - _s(2)), "ÉLIGIBILITÉ", font=_f(32, True, cond=True), fill=TEXTE)
        draw.text(
            (gx + _s(36), pad_x + _s(38)),
            f"{n} employé(s) éligible(s)  ·  OIL ROXWOOD",
            font=_f(16, cond=True), fill=TEXTE_MUTED,
        )

        y_rows = liste_top
        for i, (nom, grade) in enumerate(lignes):
            col = i // lignes_par_col
            pos = i % lignes_par_col
            x0 = pad_x + col * (col_w + _s(20))
            y0 = y_rows + pos * row_h
            ccy = y0 + (row_h - _s(8)) // 2

            draw.rounded_rectangle(
                [x0, y0, x0 + col_w - _s(8), y0 + row_h - _s(8)], radius=_s(8), fill=(255, 255, 255, 20)
            )

            couleur_grade = GRADE_COULEURS.get(grade, COULEUR_GRADE_INCONNU)
            dcx, dcy = x0 + _s(20), ccy
            draw.ellipse([dcx - _s(8), dcy - _s(8), dcx + _s(8), dcy + _s(8)], fill=couleur_grade)

            nom_aff = nom if len(nom) <= 22 else nom[:21] + "…"
            draw.text((x0 + _s(38), ccy), nom_aff, font=_f(15, True), fill=TEXTE, anchor="lm")

        buffer = io.BytesIO()
        img.save(buffer, format="PNG")
        buffer.seek(0)
        return buffer


async def setup(bot: commands.Bot):
    await bot.add_cog(SiteBridgeCog(bot))
