"""
Pont entre le bot Discord et le site Oil Roxwood.

CE FICHIER REMPLACE LA VERSION SUPABASE. Il expose exactement les mêmes
fonctions, avec les mêmes signatures : aucun autre module du bot n'a à changer.
Seule la plomberie dessous a été refaite.

Ce qui change
-------------
Avant : le bot lisait et écrivait la table `oilroxwood_etat` du projet Supabase.
Depuis la migration, le site ne lit plus Supabase du tout — il lit et écrit
`data/etat.json` dans le dépôt GitHub. Le bot écrivait donc dans une base que
plus personne ne consultait, et le site déposait des ordres que le bot ne
lisait pas. Les deux travaillaient côte à côte sans se voir.

Ici, le bot passe par le même dépôt que le site :
  · lecture  : raw.githubusercontent.com — public, sans jeton, sans limite
  · écriture : API GitHub Contents, avec un jeton personnel du bot
  · conflits : le SHA du fichier fait office de jeton de version. Si un admin
               a enregistré entre notre lecture et notre écriture, GitHub
               refuse ; on relit et on rejoue la modification. C'est pour ça
               que `maj_section` prend une FONCTION et non un objet déjà
               modifié : elle doit pouvoir être rejouée sur l'état frais.

À mettre dans le .env du bot
----------------------------
  ORX_GH_TOKEN=github_pat_…       jeton *fine-grained*, limité au seul dépôt
                                  Oil-Roxwood, permission « Contents : Read and write »
  ORX_GH_OWNER=poulpizar01        (facultatif, valeur par défaut)
  ORX_GH_REPO=Oil-Roxwood         (facultatif)
  ORX_GH_BRANCHE=main             (facultatif)

Sans jeton, `actif()` renvoie False et les intégrations site sont ignorées :
le bot continue de tourner normalement, exactement comme avant.
"""

import base64
import json
import os
import re
import time
import urllib.error
import urllib.request

OWNER = os.getenv("ORX_GH_OWNER", "poulpizar01").strip()
REPO = os.getenv("ORX_GH_REPO", "Oil-Roxwood").strip()
BRANCHE = os.getenv("ORX_GH_BRANCHE", "main").strip()
FICHIER = os.getenv("ORX_GH_FICHIER", "data/etat.json").strip()
JETON = os.getenv("ORX_GH_TOKEN", "").strip()

RAW = f"https://raw.githubusercontent.com/{OWNER}/{REPO}/{BRANCHE}/{FICHIER}"
API = f"https://api.github.com/repos/{OWNER}/{REPO}/contents/{FICHIER}"
UA = f"OilRoxwoodBot (https://github.com/{OWNER}/{REPO}, 2.0)"

ESSAIS = 4          # tentatives en cas de conflit d'écriture
_CACHE = {"t": 0, "data": None}
CACHE_MS = 5        # secondes : évite de retélécharger 500 Ko à chaque appel


def actif() -> bool:
    return bool(JETON)


# ---------- accès bas niveau ----------

def _entetes(avec_jeton=True):
    h = {"Accept": "application/vnd.github+json",
         "X-GitHub-Api-Version": "2022-11-28",
         "User-Agent": UA}
    if avec_jeton and JETON:
        h["Authorization"] = f"Bearer {JETON}"
    return h


def _lire_public():
    """Lecture rapide et sans quota. Suffit pour tout ce qui ne modifie rien."""
    req = urllib.request.Request(f"{RAW}?t={int(time.time())}", headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read().decode())


def _lire_avec_sha():
    """Lecture authentifiée : donne aussi le SHA, indispensable pour écrire."""
    req = urllib.request.Request(f"{API}?ref={BRANCHE}&t={int(time.time())}", headers=_entetes())
    with urllib.request.urlopen(req, timeout=30) as r:
        j = json.loads(r.read().decode())
    contenu = base64.b64decode(j["content"]).decode("utf-8")
    return json.loads(contenu), j["sha"]


def _ecrire(donnees, sha, message):
    corps = {
        "message": message,
        "content": base64.b64encode(json.dumps(donnees, ensure_ascii=False, indent=1).encode()).decode(),
        "branch": BRANCHE,
        "sha": sha,
    }
    req = urllib.request.Request(API, method="PUT", data=json.dumps(corps).encode(), headers=_entetes())
    urllib.request.urlopen(req, timeout=60).read()


# ---------- état partagé du dashboard ----------

def etat():
    """L'état complet du site. Mis en cache quelques secondes."""
    if _CACHE["data"] is not None and time.time() - _CACHE["t"] < CACHE_MS:
        return _CACHE["data"]
    try:
        d = _lire_public()
    except Exception:
        return None
    _CACHE["data"], _CACHE["t"] = d, time.time()
    return d


def maj_section(section, mutate):
    """Modifie UNE section de l'état partagé.

    `mutate` doit être une fonction qui modifie le dictionnaire reçu : en cas
    de conflit avec un admin, elle est REJOUÉE sur l'état fraîchement relu.
    Ne mets donc rien d'irréversible dedans.

    Les marqueurs `_maj` / `_majSec` sont ceux que le dashboard connaît : il
    intègre la modification à sa prochaine relecture sans écraser le reste.
    """
    if not JETON:
        raise RuntimeError("ORX_GH_TOKEN manquant — écriture impossible")
    derniere = None
    for tentative in range(ESSAIS):
        d, sha = _lire_avec_sha()
        mutate(d)
        maintenant = int(time.time() * 1000)
        d["_maj"] = maintenant
        d.setdefault("_majSec", {})[section] = maintenant
        d["_cid"] = "bot"
        try:
            _ecrire(d, sha, f"🤖 Bot — mise à jour ({section})")
            _CACHE["data"], _CACHE["t"] = d, time.time()
            return
        except urllib.error.HTTPError as e:
            if e.code in (409, 422):          # quelqu'un a écrit entre-temps
                derniere = e
                time.sleep(0.6 * (tentative + 1))
                continue
            raise
    raise RuntimeError(f"écriture impossible après {ESSAIS} tentatives : {derniere}")


def journal(action):
    """Trace une action du bot dans le Journal d'activité du site."""
    def _mut(d):
        j = d.setdefault("journal", [])
        j.insert(0, {"t": int(time.time() * 1000), "u": "Bot Discord", "a": action})
        del j[300:]
    try:
        maj_section("journal", _mut)
    except Exception:
        pass


def nom_site(discord_id, fallback):
    """ID Discord -> nom RP via les comptes d'accès du site."""
    try:
        d = etat() or {}
        for u in d.get("users", []):
            if str(u.get("did", "")) == str(discord_id):
                return u.get("user") or fallback
    except Exception:
        pass
    return fallback


# ---------- tables annexes ----------
# Elles vivaient dans Supabase, elles vivent maintenant sous la clé `_tables`
# du même fichier. On reproduit le petit sous-ensemble de PostgREST que le bot
# utilise réellement : `col=eq.valeur`, `order=col`, `select=*`, `limit=n`.

def _filtres(query):
    """'did=eq.123&order=date' -> ([('did','123')], 'date', None)"""
    egaux, ordre, limite = [], None, None
    for morceau in str(query or "").split("&"):
        if not morceau or "=" not in morceau:
            continue
        cle, val = morceau.split("=", 1)
        if cle == "select":
            continue
        if cle == "order":
            ordre = val.split(".")[0]
        elif cle == "limit":
            limite = int(val) if val.isdigit() else None
        elif val.startswith("eq."):
            egaux.append((cle, val[3:]))
    return egaux, ordre, limite


def _correspond(ligne, egaux):
    return all(str(ligne.get(c, "")) == str(v) for c, v in egaux)


def table_select(table, query=""):
    d = etat() or {}
    lignes = list(((d.get("_tables") or {}).get(table)) or [])
    egaux, ordre, limite = _filtres(query)
    lignes = [l for l in lignes if _correspond(l, egaux)]
    if ordre:
        lignes.sort(key=lambda l: str(l.get(ordre, "")))
    return lignes[:limite] if limite else lignes


def table_insert(table, row):
    """Ajoute une ligne. L'identifiant est attribué ici, comme le faisait Supabase."""
    def _mut(d):
        t = d.setdefault("_tables", {})
        lignes = t.setdefault(table, [])
        if "id" not in row or row["id"] is None:
            ids = [l.get("id") for l in lignes if isinstance(l.get("id"), int)]
            row["id"] = (max(ids) + 1) if ids else 1
        lignes.append(row)
    maj_section("_tables", _mut)


def table_update(table, query, champs):
    """Absent de la version Supabase, mais nécessaire pour répondre aux ordres du site."""
    egaux, _, _ = _filtres(query)
    def _mut(d):
        for l in ((d.setdefault("_tables", {}).setdefault(table, []))):
            if _correspond(l, egaux):
                l.update(champs)
    maj_section("_tables", _mut)


def table_delete(table, query):
    egaux, _, _ = _filtres(query)
    def _mut(d):
        t = d.setdefault("_tables", {})
        t[table] = [l for l in (t.get(table) or []) if not _correspond(l, egaux)]
    maj_section("_tables", _mut)


# ---------- utilitaires (inchangés) ----------

def date_iso(txt):
    """'14/08', '14/08/2026', '2026-08-14' -> 'AAAA-MM-JJ' (None si illisible)."""
    t = str(txt or "").strip()
    m = re.match(r"^(\d{4})-(\d{2})-(\d{2})", t)
    if m:
        return t[:10]
    m = re.match(r"^(\d{1,2})[/\-. ](\d{1,2})[/\-. ](\d{2,4})$", t)
    if m:
        j, mo, a = int(m.group(1)), int(m.group(2)), int(m.group(3))
        a += 2000 if a < 100 else 0
        return f"{a:04d}-{mo:02d}-{j:02d}"
    m = re.match(r"^(\d{1,2})[/\-. ](\d{1,2})$", t)
    if m:
        import datetime
        return f"{datetime.date.today().year:04d}-{int(m.group(2)):02d}-{int(m.group(1)):02d}"
    return None
